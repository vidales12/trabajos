<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="../../assets/js/color-modes.js"></script>
  <style>
    .registro{
        background color: lavender;
        height: 50hv;
        margin: 5%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }
  </style>
  <div class="registro">
  <h1 class="modal-title fs-5"> ingrese los siguientes datos</h1>
    <body style="background-color:#94bcff ;">
    <a>correo electronico</a>
    <input type="gmail" name="correo" placeholder="correo" require>
    <br>
    <a>nombre y apellido</a>
    <input type="text" name="txt_nombre" placeholder="nombre"require>
    <br>
    <a>numero de celular</a>
    <input type="number" name="txt_celular" placeholder="celular"require>
    <br>
    <a>ciudad de residencia</a>
    <input type="city" name="txt_ciudad" placeholder="lugar de residencia"require>
    <br>
    <a>fecha de registro</a>
    <input type="datetime-local" name="txt_fecha" placeholder="fecha"require>
    <br>
    <a>direccion</a>
    <input type="text" name="txt_direccion" placeholder="direccion" require>
    <br>
    <input type="button" value="aceptar">
  </body>
  </div>