<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="../../assets/js/color-modes.js"></script>
  <style>
    .registro{
        background color: lavender;
        height: 50hv;
        margin: 5%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }
  </style>
  <div class="registro">
  <h1 class="modal-title fs-5">contacta directamente a nuestro chat de whatsApp</h1>
    <body style="background-color:#94bcff ;">
        <a>314 2862829</a>
  </body>
  </div>