<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="../../assets/js/color-modes.js"></script>
  <style>
    .registro{
        background color: lavender;
        height: 50hv;
        margin: 5%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }
  </style>
  <div class="registro">
  <h1 class="modal-title fs-5">puesto disponible para ingeneria civil</h1>
    <body style="background-color:#94bcff ;">
        <a>nuestras instalaciones contamos un buen ambiente labol y todo lo apto y necesario para el trabajo</a>
        <br>
        <a>horarios de lunes a viernes de 7:00AM a 5:00PM</a>
  </body>
  </div>