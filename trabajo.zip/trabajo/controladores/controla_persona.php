<?php
$nombre = $_POST["text_nombre"];
$documento = $_POST["txt_numero"];
$edad = $_POST["txt_edad"];
if($edad>=18)    
{
echo "tome guaro <br>";
}else{
if($edad<=17)
echo "eche pa la casa <br>";
}
echo $nombre." - ".$documento;
?>