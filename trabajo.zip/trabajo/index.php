<script>
window.location = function() {
  Window.location.href = 'public/index.php'
}
</script>